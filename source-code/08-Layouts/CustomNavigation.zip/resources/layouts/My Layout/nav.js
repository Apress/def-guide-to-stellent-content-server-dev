//////////////////////////////////////////////////////////////
//
// Use the 'navBuilder' object in the function 'initCustomNodes'
//   to add/remove/modify navigation nodes. The methods in the
//   'navBuilder' object are defined in the file 'common.js'.
//   examples of how to use the object are in 'commonNav.js'
//
// If you are writing a component, you should not modify this file.
//   Instead, override the include 'custom_finish_layout_init' with
//   the 'super' tag, and modify the 'navBuilder' object there.
//
//////////////////////////////////////////////////////////////

function initCustomNodes(navBuilder)
{

}

