//////////////////////////////////////////////////////////////
//
// YOU SHOULD NEVER MODIFY THIS FILE!
//
// If you wish to modify a layout, you should place all your code
//   in the function 'initCustomNodes' in the 'nav.js' file.
//
// If you are writing a component, you should override the include
//   'custom_finish_layout_init' with the 'super' tag, and modify
//   the 'navBuilder' object there.
//
// If you wish to make modifications that require changes to this
//   file, you should instead create en entirely new layout based
//   on this one.
//
//////////////////////////////////////////////////////////////

/* IMAGE DEFINITION CODE ***************************************************************************/
/***************************************************************************************************/

/* Nav tree image src values. */
var src_I = httpSkinRoot + "tree_I.gif";
var src_Icon_ColClosed = httpSkinRoot + "tree_icon_collection_closed.gif";
var src_Icon_ColOpen = httpSkinRoot + "tree_icon_collection_open.gif";
var src_Icon_Item = httpSkinRoot + "tree_icon_item.gif";
var src_L_ColClosed = httpSkinRoot + "tree_L_collection_closed.gif";
var src_L_ColOpen = httpSkinRoot + "tree_L_collection_open.gif";
var src_T_ColClosed = httpSkinRoot + "tree_T_collection_closed.gif";
var src_T_ColOpen = httpSkinRoot + "tree_T_collection_open.gif";
var src_L_Item = httpSkinRoot + "tree_L_item.gif";
var src_T_Item = httpSkinRoot + "tree_T_item.gif";
var src_Space = httpSkinRoot + "tree_space.gif";
var src_Top_ColClosed = httpSkinRoot + "tree_top_collection_closed.gif";
var src_Top_ColOpen = httpSkinRoot + "tree_top_collection_open.gif";
var src_Top_Item = httpSkinRoot + "tree_top_item.gif";

/* Nav tree image height and width values. */
var iconWidth_Col = "16";
var iconHeight_Col = "16";
var iconWidth_Item = "16";
var iconHeight_Item = "16";
var connectorWidth = "12";
var connectorHeight = "20";
var arrowRightImageWidth = "11";
var arrowRightImageHeight = "11";
var arrowDownImageWidth = "11";
var arrowDownImageHeight = "11";

/* Header/menu bar image src values */
var logoImage = httpSkinRoot + "HeaderLogo.gif";
var menuBarDividerImage = httpSkinRoot + "menu_bar_divider.gif";
var menuA_arrowDownImage = httpSkinRoot + "menuA_ArrowDown.gif";
var menuA_arrowDownOverImage = httpSkinRoot + "menuA_ArrowDown_over.gif";
var menuB_arrowDownImage = httpSkinRoot + "menuB_ArrowDown.gif";
var menuB_arrowDownOverImage = httpSkinRoot + "menuB_ArrowDown_over.gif";
var menuA_arrowRightImage = httpSkinRoot + "menuA_ArrowRight.gif";
var menuA_arrowRightOverImage = httpSkinRoot + "menuA_ArrowRight_over.gif";
var menuB_arrowRightImage = httpSkinRoot + "menuB_ArrowRight.gif";
var menuB_arrowRightOverImage = httpSkinRoot + "menuB_ArrowRight_over.gif";


/* PAGE DISPLAY INITIALIZATION CODE ****************************************************************/
/***************************************************************************************************/


function writeLayoutPageBegin()
{
	var beginHtml = "";

	/* Genreate opening navigation shell markup. */
	beginHtml +=
	'<!-- Begin Navigation Shell table -->\n' +
	'<table style="width:100%; height:100%" border="0" cellspacing="0" cellpadding="0">\n' +
	'<tr>\n' +
	'<td class="menuA_HeaderCell">\n' +
	'	<!-- Header Table -->\n' +
	'	<table id="headerTable" style="width:100%" border="0" cellspacing="0" cellpadding="0">\n' +
	'		<tr>\n' +
	'			<td colspan="4" class="menuA_HeaderLogoCell">\n' +
	'				<table style="width:100%" border="0" cellspacing="0" cellpadding="0">\n' +
	'					<tr>\n' +
	'						<td class="logoImageCell">\n' +
	'							<img src="' + logoImage + '"></td>\n' +
	'						<td id="quickSearchCell" style="white-space:nowrap; text-align:right; vertical-align:middle; padding-left:0pt; padding-right:6pt; padding-top:5px; padding-bottom:7px">\n' +
	'							<!-- *** Quick Search container *** --></td>\n' +
	'					</tr>\n' +
	'				</table>\n' +
	'			</td>\n' +
	'		</tr>\n' +
	'		<tr>\n' +
	'			<td colspan="4" class="menuA_HeaderSpacerCell"><img src="' + src_Space + '" width="16" height="1"></td>\n' +
	'		</tr>\n' +
	'		<tr>\n' +
	'			<td id="menuA" class="menuA_HeaderMenuCell" width="10">\n' +
	'					<!-- *** menuA container *** --></td>\n' +
	'			<td class="menuA_TopMenuBarDividerCell">\n' +
	'					<img src="' + menuBarDividerImage + '" width="37" height="19"></td>\n' +
	'			<td colspan=2 id="menuBarExtrasCell" class="menuA_TopMenuBarRightCell">\n' +
	'				<!-- *** Menu Bar Extras container *** --></td>\n' +
	'		</tr>\n' +
	'		<tr>\n' +
	'			<td id="menuB_spacer" class="menuB_MenuSpacerCell" colspan="4" height="1">\n' +
	'					<img src="' + src_Space + '" width="1" height="1"></td>\n' +
	'		</tr>\n' +
	'		<tr class="menuB_HeaderMenuCell">\n' +
	'			<td id="menuB" width="10" colspan=3>\n' +
	'					<!-- *** menuB container *** --></td>\n' +
	'			<td colspan=1>&nbsp;</td>\n' +
	'		</tr>\n' +
	'	</table>\n' +
	'</td>\n' +
	'</tr>\n' +
	'<tr>\n' + // This row provides the highlight line/spacer along the top of the main window.
	'<td class="ContentWindowSpacerCell" height="1">\n' +
	'	<img src="' + src_Space + '" width="1" height="1"></td>\n' +
	'</tr>\n' +
	'<tr>\n' +
	'<td class="ContentWindowCell">\n';

	/* Genreate opening core content area markup. */
	beginHtml +=
	'	<!-- Main display area table -->\n' +
	'	<table class="MainContentTable" align="center" border="0" cellspacing="0" cellpadding="0">\n' +
	'		<tr>\n' +
	'		  <td style="text-align:center;vertical-align:top;padding:15px">\n' +
	'				<center>\n';

	document.write(beginHtml);
	document.close();
}


function writeLayoutPageEnd()
{
	var endHtml = "";

	/* Generate closing core content area markup. */
	endHtml +=
	'				</center>\n' +
	'			</td>\n' +
	'		</tr>\n' +
	'	</table><!-- End main display area table -->\n';	

	/* Generate closing navigation shell markup. */
	endHtml +=
	'  </td>\n' +
	'</tr>\n' +
	'<tr>\n' +
	'  <td>\n' +
	'    <div>Copyright 2005 Nunya Business Dot Com</div>' +
	'  </td>\n' +
	'</tr>\n' +
	'</table><!-- End Navigation Shell container -->\n';

	document.write(endHtml);
	document.close();
}


function layoutInitialize()
{
	loadNavshell();
}


/* This function is called by the onload event of the nav_display.htm document. */
function generateNavigation()
{
	// init the top menu with just links
	coreNav.menuA = new navBuilder();
	coreNav.menuA.topLevelNodes = new Array (
		"LOGIN", "MICROSOFT_LOGIN", "SELF_REGISTRATION", "HOME", "LOCAL_HOME", "SEARCH",
		"NEW_CHECK_IN", "MY_PROFILE", "HELP" );
	coreNav.menuA.makeOpeningHtml = menuA_MenuItem_OpeningHtml;
	coreNav.menuA.makeCoreHtml = menuA_MenuItem_CoreHtml;
	coreNav.menuA.makeClosingHtml = menuA_MenuItem_ClosingHtml;

	// init the top menu with the drop-down lists
	coreNav.menuB = new navBuilder();
	coreNav.menuB.topLevelNodes = new Array (
		"MY_STELLENT", "BROWSE_CONTENT", "CONTENT_MANAGEMENT", "ADMINISTRATION" );
	coreNav.menuB.makeOpeningHtml = menuB_MenuItem_OpeningHtml;
	coreNav.menuB.makeCoreHtml = menuB_MenuItem_CoreHtml;
	coreNav.menuB.makeClosingHtml = menuB_MenuItem_ClosingHtml;

	/* This function generates an associative array object containing pointers to
		all the elements in the master XML tree; this enables elements to be randomly
		accessed using the getNodeById() funciton. */
	coreNav.xmlNodeMap = new Object();
	mapXMLTree(coreNav.xmlRoot, coreNav.xmlNodeMap);
	//DEBUG_displayNodeMap(coreNav.xmlNodeMap);

	/* initialize the navigation nodes */
	addStandardNavigationNodes(coreNav);
	
	/* add custom nodes - be careful of JavaScript errors */
	try
	{
		initCustomNodes(coreNav);
		finishLayoutInit(coreNav);
	}
	catch (e)
	{
		alert("layout.js: " + e);
	}

	//DEBUG_displayNodeMap(coreNav.xmlNodeMap);

	//***** menuA *************************************

	/* Run the routine that copies nodes from the master XML document to the dropdown menu XML
		fragment. The coreNav.menuA.topLevelNodes array is passed in as a parameter to provide the
		list of nodes to be included in this display group (coreNav.menuA.topLevelNodes is loaded
		in nav.js). */
	buildTopLevelItems(coreNav.menuA.topLevelNodes, coreNav.menuA.xmlRoot, coreNav);

	/* Create a map of the XML fragment to be used by the getNodeById() funciton. */
	coreNav.menuA.xmlNodeMap = new Object();
	mapXMLTree(coreNav.menuA.xmlRoot, coreNav.menuA.xmlNodeMap);
	//DEBUG_displayNodeMap(coreNav.menuA.xmlNodeMap);

	/* Ensure that the menuA htmlString variable is empty before generating menu code. */
	coreNav.menuA.htmlString = "";

	/* Run the routine that recursively generates HTML code from the dropdown menu XML fragment. */
	coreNav.menuA.buildHtmlStringFromXml(coreNav.menuA.xmlRoot);
	//window.open("javascript:document.write(opener.coreNav.menuA.htmlString)", 'testWin');

	/* Run the routine that inserts the HTML code string into the menuA container. */
	var menuA_Container = document.getElementById("menuA");
	insertHtml(coreNav.menuA.htmlString, menuA_Container);

	//***** menuB *************************************

	/* Run the routine that copies nodes from the master XML document to the tree menu XML
		fragment. The coreNav.menuB.topLevelNodes array is passed in as a parameter to provide the
		list of nodes to be included in this display group (coreNav.menuB.topLevelNodes is loaded
		in nav.js). */
	buildTopLevelItems(coreNav.menuB.topLevelNodes, coreNav.menuB.xmlRoot, coreNav);

	/* Create a map of the XML fragment to be used by the getNodeById() funciton. */
	coreNav.menuB.xmlNodeMap = new Object();
	mapXMLTree(coreNav.menuB.xmlRoot, coreNav.menuB.xmlNodeMap);
	//DEBUG_displayNodeMap(coreNav.menuB.xmlNodeMap);

	/* Ensure that the menuB htmlString variable is empty before generating menu code. */
	coreNav.menuB.htmlString = "";

	/* Run the routine that recursively generates HTML code from the dropdown menu XML fragment. */
	coreNav.menuB.buildHtmlStringFromXml(coreNav.menuB.xmlRoot);
	//window.open("javascript:document.write(opener.coreNav.menuB.htmlString)", 'testWin');

	/* Run the routine that inserts the HTML code string into the menuB container. */
	var menuB_Container = document.getElementById("menuB");
	insertHtml(coreNav.menuB.htmlString, menuB_Container);


	//***** POPULATE ADD'L DISPLAY CONTAINERS ****************

	var quickSearchContainer = document.getElementById("quickSearchCell");
	insertHtml(quickSearchFormHtmlCode(coreNav), quickSearchContainer);

	var menuBarExtrasContainer = document.getElementById("menuBarExtrasCell");
	insertHtml(menuBarExtrasHtmlCode(), menuBarExtrasContainer);
}


function buildTopLevelItems(idList, XMLRoot, navBuilder)
{
	var nodeCopy;
	for (var i=0; i<idList.length; i++)
	{
		if (navBuilder.getNodeById(idList[i]))
		{
			var node = navBuilder.getNodeById(idList[i]);
			nodeCopy = node.cloneNode(true);
			XMLRoot.appendChild(nodeCopy);
		}
	}
}


/* MENU_A DISPLAY CODE ***************************************************************************/
/***************************************************************************************************/

function menuA_MenuItem_OpeningHtml(node, nodeLocation)
{
	var id = "menuA_" + nodeLocation;

	if (node.tagName == "navtree") // Top-level horizontal menu listing
	{
		this.htmlString +=
			'<table border="0" cellpadding="0" cellspacing="0">\n' +
			'<tr>\n';
	}
	else 
	{
		prefix = "Sub";
		if (node.parentNode.tagName == "navtree") // First-tier child menus
			prefix = "Top";
		
		this.htmlString +=
			'<div id="' + id + '_menu" class="menuA_'+prefix+'ChildCollectionContainer" style="display:none">\n' +
			'	<div class="menuA_'+prefix+'ChildCollectionOutline">\n' +
			'		<table class="menuA_'+prefix+'ChildListTable" border="0" cellpadding="0" cellspacing="0">\n' +
			'		<tr><td><img src="' + src_Space + '" width="1" height="2"></td></tr>\n';
	}
}


function menuA_MenuItem_CoreHtml(node, nodeLocation)
{
	var labelString;
	var linkTarget = node.getAttribute("target");
	var label = node.getAttribute("label");
	var url = node.getAttribute("url");
	var id = "menuA_" + nodeLocation;

	if (node.parentNode.tagName == "navtree") // Top-level menu items
	{
		if (node.tagName == "item")
		{
			/* Generate target attribute code for the <a> tag if a target attribute exists in the XML. */
			if (linkTarget == null || linkTarget == "")
				linkTarget = "_self";

			this.htmlString +=
				'<td id="' + id + '" class="menuA_TopLinkItem" nowrap onclick="linkItem_onclick(event, this)" onmouseover="linkItem_mouseover(this)" onmouseout="linkItem_mouseout(this)">\n' +
				'	<a class="menuA_TopLinkText" href="'+url+'" target="'+linkTarget+'">' + label + '</a>\n' +
				'</td>\n';
		}

		else if (node.tagName == "collection")
		{
			this.htmlString +=
				'<td id="' + id + '" onclick="topCollectionItem_onclick(event, this, \''+id+'_menu\', \'vertical\')" onmouseover="topCollectionItem_mouseover(event, this)" onmouseout="topCollectionItem_mouseout(event, this)">\n' +
				'	<table id="' + id + '_itemTable" class="menuA_TopCollectionItemTable" border="0" cellpadding="0" cellspacing="0">\n' +
				'		<tr>\n' +
				'			<td id="' + id + '_arrowCell" class="menuA_TopCollectionItemArrowCell">\n' +
				'				<img id="' + id + '_arrowImg" src="' + menuA_arrowDownImage + '" width="' + arrowDownImageWidth + '" height="' + arrowDownImageHeight + '"></td>\n' +
				'			<td id="' + id + '_labelCell" class="menuA_TopCollectionItem" nowrap>\n' +
				'				' + label + '</td>\n' +
				'		</tr>\n' +
				'	</table>\n';
		}

	}

	else // Child menu items
	{
		if (node.tagName == "item")
		{
			/* Generate target attribute code for the <a> tag if a target attribute exists in the XML. */
			if (linkTarget == null || linkTarget == "")
				linkTarget = "_self";

			this.htmlString +=
				'<tr>\n' +
				'	<td id="' + id + '" class="menuA_ChildLinkItem" nowrap onclick="linkItem_onclick(event, this)" onmouseover="linkItem_mouseover(this)" onmouseout="linkItem_mouseout(this)">\n' +
				'	<a class="menuA_ChildLinkText" href="'+url+'" target="'+linkTarget+'">' + label + '</a>\n' +
				'	</td>\n' +
				'</tr>\n';
		}

		else if (node.tagName == "collection")
		{
			this.htmlString +=
				'<tr>\n' +
				'	<td id="' + id + '" onclick="childCollectionItem_onclick(event, this, \''+id+'_menu\')" onmouseover="childCollectionItem_mouseover(event, this)" onmouseout="childCollectionItem_mouseout(event, this)">\n' +
				'		<table id="' + id + '_itemTable" class="menuA_ChildCollectionItemTable" style="width:100%" border="0" cellpadding="0" cellspacing="0">\n' +
				'			<tr>\n' +
				'				<td id="' + id + '_labelCell" class="menuA_ChildCollectionItem" nowrap>\n' +
				'					' + label + '</td>\n' +
				'				<td id="' + id + '_arrowCell" class="menuA_ChildCollectionItemArrowCell">\n' +
				'					<img id="' + id + '_arrowImg" src="' + menuA_arrowRightImage + '" width="' + arrowRightImageWidth + '" height="' + arrowRightImageHeight + '"></td>\n' +
				'			</tr>\n' +
				'		</table>\n';
		}
	}
}


function menuA_MenuItem_ClosingHtml(node, nodeLocation)
{
	if (node.tagName == "navtree") // Top-level horizontal menu listing
	{
		this.htmlString +=
			'	</tr>\n' +
			'</table>\n';
	}

	else 
	{
		this.htmlString +=
			'				<tr>\n' +
			'					<td>\n' +
			'						<img src="' + src_Space + '" width="1" height="2"></td>\n' +
			'				</tr>\n' +
			'			</table>\n' +
			'		</div>\n' +
			'	 </div>\n' +
			'</td>\n'; // Closing tag for parent cell
		
		if (node.parentNode.tagName != "navtree")
			this.htmlString += '</tr>\n';
	}
}


/* Standard function for generating html image tag code. */
function imageHtml(src, w, h)
{
	var imgHtml = '<img src="' + src + '" width="' + w + '" height="' + h + '" border="0" align="absmiddle">';
	return imgHtml
}


function quickSearchFormHtmlCode(navBuilder)
{
	return quickSearchForm;
}


function menuBarExtrasHtmlCode()
{
	var htmlString = "";

	htmlString +=
		'<table align="right" border="0" cellpadding="0" cellspacing="0">\n' +
		'	<tr>\n';

	htmlString +=
		'	</tr>\n' +
		'</table>\n';

	return htmlString;
}


/* MENU_B DISPLAY CODE ***************************************************************************/
/***************************************************************************************************/


function menuB_MenuItem_OpeningHtml(node, nodeLocation)
{
	var id = "menuB_" + nodeLocation;

	if (node.tagName == "navtree") // Top-level horizontal menu listing
	{
		this.htmlString +=
			'<table border="0" cellpadding="0" cellspacing="0">\n' +
			'<tr>\n';
	}

	else 
	{
		var prefix = "Sub"
		if (node.parentNode.tagName == "navtree") // First-tier child menus
			prefix = "Top";
			
		this.htmlString +=
			'<div id="' + id + '_menu" class="menuB_'+prefix+'ChildCollectionContainer" style="display:none">\n' +
			'	<div class="menuB_'+prefix+'ChildCollectionOutline">\n' +
			'		<table class="menuB_'+prefix+'ChildListTable" border="0" cellpadding="0" cellspacing="0">\n' +
			'			<tr><td><img src="' + src_Space + '" width="1" height="2"></td></tr>\n';
	}
}


function menuB_MenuItem_CoreHtml(node, nodeLocation)
{
	var labelString;
	var linkTarget = node.getAttribute("target");
	var label = node.getAttribute("label");
	var url = node.getAttribute("url");
	var id = "menuB_" + nodeLocation;

	if (node.parentNode.tagName == "navtree") // Top-level menu items
	{
		if (node.tagName == "item")
		{
			/* Generate target attribute code for the <a> tag if a target attribute exists in the XML. */
			if (linkTarget == null || linkTarget == "")
				linkTarget = "_self";

			this.htmlString +=
				'<td id="' + id + '" class="menuB_TopLinkItem" nowrap onclick="linkItem_onclick(event, this)" onmouseover="linkItem_mouseover(this)" onmouseout="linkItem_mouseout(this)">\n' +
				'	<a class="menuB_TopLinkText" href="'+url+'" target="'+linkTarget+'">' + label + '</a>\n' +
				'</td>\n';
		}

		else if (node.tagName == "collection")
		{
			this.htmlString +=
				'<td id="' + id + '" onclick="topCollectionItem_onclick(event, this, \''+id+'_menu\', \'vertical\')" onmouseover="topCollectionItem_mouseover(event, this)" onmouseout="topCollectionItem_mouseout(event, this)">\n' +
				'	<table id="' + id + '_itemTable" class="menuB_TopCollectionItemTable" border="0" cellpadding="0" cellspacing="0">\n' +
				'		<tr>\n' +
				'			<td id="' + id + '_arrowCell" class="menuB_TopCollectionItemArrowCell">\n' +
				'				<img id="' + id + '_arrowImg" src="' + menuB_arrowDownImage + '" width="' + arrowDownImageWidth + '" height="' + arrowDownImageHeight + '"></td>\n' +
				'			<td id="' + id + '_labelCell" class="menuB_TopCollectionItem" nowrap>\n' +
				'				' + label + '</td>\n' +
				'		</tr>\n' +
				'	</table>\n';
		}

	}

	else // Child menu items
	{
		if (node.tagName == "item")
		{
			/* Generate target attribute code for the <a> tag if a target attribute exists in the XML. */
			if (linkTarget == null || linkTarget == "")
				linkTarget = "_self";

			this.htmlString +=
				'<tr>\n' +
				'	<td id="' + id + '" class="menuB_ChildLinkItem" nowrap onclick="linkItem_onclick(event, this)" onmouseover="linkItem_mouseover(this)" onmouseout="linkItem_mouseout(this)">\n' +
				'		<a class="menuB_ChildLinkText" href="'+url+'" target="'+linkTarget+'">' + label + '</a>\n'+
				'	</td>\n' +
				'</tr>\n';
		}
		else if (node.tagName == "collection")
		{
			this.htmlString +=
				'<tr>\n' +
				'	<td id="' + id + '" onclick="childCollectionItem_onclick(event, this, \''+id+'_menu\')" onmouseover="childCollectionItem_mouseover(event, this)" onmouseout="childCollectionItem_mouseout(event, this)">\n' +
				'		<table id="' + id + '_itemTable" class="menuB_ChildCollectionItemTable" style="width:100%" border="0" cellpadding="0" cellspacing="0">\n' +
				'			<tr>\n' +
				'				<td id="' + id + '_labelCell" class="menuB_ChildCollectionItem" nowrap>\n' +
				'					' + label + '</td>\n' +
				'				<td id="' + id + '_arrowCell" class="menuB_ChildCollectionItemArrowCell">\n' +
				'					<img id="' + id + '_arrowImg" src="' + menuB_arrowRightImage + '" width="' + arrowRightImageWidth + '" height="' + arrowRightImageHeight + '"></td>\n' +
				'			</tr>\n' +
				'		</table>\n';
		}
	}
}


function menuB_MenuItem_ClosingHtml(node, nodeLocation)
{
	if (node.tagName == "navtree") // Top-level horizontal menu listing
	{
		this.htmlString +=
			'	</tr>\n' +
			'</table>\n';
	}

	else 
	{
		this.htmlString +=
			'				<tr>\n' +
			'					<td>\n' +
			'						<img src="' + src_Space + '" width="1" height="2"></td>\n' +
			'				</tr>\n' +
			'			</table>\n' +
			'		</div>\n' +
			'	 </div>\n' +
			'</td>\n'; // Closing tag for parent cell
		
		if (node.parentNode.tagName != "navtree") // First-tier child menus
			this.htmlString += '</tr>\n';
	}
}


/* Set global click event handler that's used to close menus when a user clicks anywhere
	outside of the menu objects (needed for Netscape only). */
document.onclick = resetMenus;

