CustomNavigation Component
==========================

This component demonstrates a few ways to add navigation nodes, pop-up
menus, custom skins, and custom layouts.

This is a simplification of the free ModifyLayout sample component.
