HelloUser Component
===================

An extremely basic component with a template, a service, and an include.
