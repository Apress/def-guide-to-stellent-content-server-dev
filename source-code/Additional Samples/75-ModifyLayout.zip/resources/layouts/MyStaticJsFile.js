
/*

If you JavaScript code is highly static, meaning that you do not
need any IdocScript in it, then you can place it into a function
in this static JavaScript file, and call your function from
inside the 'custom_finish_layout_init' include

It is usually desirable to put large amounts of JavaScript into
seperate files, particularly if the data does not change very
often. This speed up the client browsers greatly.

If you have a lot of JavaScript, and need some IdocScript
values to trigger special cases, then you should map those
IdocScript variables to JavaScript variables. See the includes
'custom_js_bootstrap_vars' and 'custom_personalized_js_bootstrap_vars'
for more info.

*/

function doMyStaticStuff()
{
}