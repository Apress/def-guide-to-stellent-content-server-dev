function submitMiniSearchFrm()
{
	// Iterate through all fields in components of building up a QueryText.
	var curOperator = "";
	var queryText = "";
	var queryFullText = "";
	var searchProviders = "";

	for (var i = 0; i < document.QUERYTEXTCOMPONENTS.elements.length; i++)
	{
		var elt = document.QUERYTEXTCOMPONENTS.elements[i];
		if (elt.name == 'subStringOnly')
		{
			curOperator = " <Substring> ";
			curOpVal = "Substring";
		}
		else
		{
			if (curOperator.length > 0)
			{
				var text = elt.value;
				if (text.length > 0)
				{
					if (queryText.length > 0)
					{
						queryText += " <AND> ";
					}
					queryText += elt.name + curOperator + "`" + text + "`";
				}
				curOperator = "";
			}
		}
	}

	// Add on full text part of QueryText.
	var text = document.QUERYTEXTCOMPONENTS.FullTextSearch.value;
	if (text.length > 0)
	{
		// Full text highlighting is potentially useful.
		document.SEARCHFORM.ftx.value = "1";

		// add to query text
		var oldlen = queryText.length;
		if (oldlen > 0)
		{
			queryText += " <AND> (";
		}
		queryText += text;
		if (oldlen > 0)
		{
			queryText += ")";
		}
		queryFullText = text;
	}

	document.SEARCHFORM.QueryText.value = queryText;
	defaultStatus = "Query: " + queryText;

	document.SEARCHFORM.submit();
}

 // Move option list values to corresponding text field when selected
function setOption(menu)
{
	// Find menu in form.
	var index = -1;
	for (var i = 0; i < document.QUERYTEXTCOMPONENTS.elements.length; i++)
	{
		if (document.QUERYTEXTCOMPONENTS.elements[i].name == menu.name)
		{
			index = i - 1;
			break;
		}
	}
	if (index < 0)
	{
		alert("Could not find this value in the form list: " + menu.name);
		return;
	}

	var field = document.QUERYTEXTCOMPONENTS.elements[index];

	field.value = menu.options[menu.selectedIndex].text;
}

function clearQueryText()
{
	document.QUERYTEXTCOMPONENTS.reset();
	document.SEARCHFORM.QueryText.value = "";
	document.SEARCHFORM.SortSpec.value="dInDate DESC";
	document.SEARCHFORM.SortSpecText.value="Release Date Descending";
}

function submitFrm()
{
	// Iterate through all fields in components of building up a QueryText.
	var curOperator = "";
	var curOpVal = "";
	var queryText = "";
	var queryFieldValues = "";
	var queryFullText = "";
	var searchProviders = "";

	for (var i = 0; i < document.QUERYTEXTCOMPONENTS.elements.length; i++)
	{
		var elt = document.QUERYTEXTCOMPONENTS.elements[i];
		if (elt.name == "op")
		{
			var selIndex = elt.selectedIndex;
			var op = elt.options[selIndex].value
			if (op == "Before")
			{
				curOperator = " < ";
			}
			else if (op == "After")
			{
				curOperator = " > ";
			}
			else if (op == "GreaterEqual")
			{
				curOperator = " >= ";
			}
			else if (op == "LessEqual")
			{
				curOperator = " <= ";
			}
			else
			{
				curOperator = " <" + op + "> ";
			}
			curOpVal = op;
		}
		else if (elt.name == "opSelected")
		{
			var op = elt.value;
			if (op == "Before")
			{
				curOperator = " < ";
			}
			else if (op == "After")
			{
				curOperator = " > ";
			}
			else if (op == "GreaterEqual")
			{
				curOperator = " >= ";
			}
			else if (op == "LessEqual")
			{
				curOperator = " <= ";
			}
			else
			{
				curOperator = " <" + op + "> ";
			}
			curOpVal = op;
		}
		// PNE handling
		else if (elt.name == 'subStringOnly')
		{
			curOperator = " <Substring> ";
			curOpVal = "Substring";
		}
		else if (elt.name == "searchable" && (elt.type=="hidden" || elt.checked))
		{
			searchProviders = elt.value + "," + searchProviders
		}
		else
		{
			if (curOperator.length > 0)
			{

				var name = elt.name;
				var text = "";
				if (name == "dDocType")
				{
					if (document.SEARCHFORM.AdvSearch.value == "True")
					{
						text = elt.value;
					}
					else
					{
						// This value comes directly from a select field.
						var selIndex = elt.selectedIndex;
						text = elt.options[selIndex].value;
					}
				}
				else if (name == "dClbraName")
				{
					name = "dDocAccount";
					if (elt.value.length > 0)
					{
						text = "prj/" + elt.value;
					}

				}
				else
				{
					text = elt.value;
				}

				if (text.length > 0)
				{
					if (queryText.length > 0)
					{
						queryText += " <AND> ";
					}
					queryText += elt.name + curOperator + "`" + text + "`";
					queryFieldValues += elt.name + "\n" + curOpVal + "\n" + text + "\n";
				}
				curOperator = "";
			}
		}
	}

	// Add on full text part of QueryText.
	var text = document.QUERYTEXTCOMPONENTS.FullTextSearch.value;
	if (text.length > 0)
	{
		// Full text highlighting is potentially useful.
		document.SEARCHFORM.ftx.value = "1";
	}
	else
	{
		document.SEARCHFORM.ftx.value= "";
	}

	if (text.length > 0)
	{
		var oldlen = queryText.length;
		if (oldlen > 0)
		{
			queryText += " <AND> (";
		}
		queryText += text;
		if (oldlen > 0)
		{
			queryText += ")";
		}
		queryFullText = text;
	}


	document.SEARCHFORM.QueryText.value = queryText;

	defaultStatus = "Query: " + queryText;
	document.SEARCHFORM.submit();
}

function clearSortSpec(frm)
{
	frm.SortSpec.value = "";
	frm.SortSpecText.value = "";
}

function updateSortSpec(frm)
{
	var value = frm.SortSpec.value;

	var fieldIndex = frm.SortField.selectedIndex;
	if (fieldIndex < 0)
		fieldIndex = 0;

	var orderIndex = frm.SortOrder.selectedIndex;
	if (orderIndex < 0)
		orderIndex = 0;

	// fill in the invisible field
	var field = frm.SortField.options[fieldIndex].value;
	var order = frm.SortOrder.options[orderIndex].value;
	frm.SortSpec.value = value + " " + field + " " + order;

	// fill in the text displayed to the user
	var text = frm.SortSpecText.value;
	field = frm.SortField.options[fieldIndex].text;
	order = frm.SortOrder.options[orderIndex].text;

	if (text.length > 0)
	{
		text = text + ", then ";
	}
	frm.SortSpecText.value = text + field + " " + order;
}