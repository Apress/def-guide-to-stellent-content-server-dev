StartupService Component
========================

This component is used to scan a folder upon startup, and check in each item
in that folder. It demonstrates how to execute a service request from a
filter, and more generically from any Java code.

Changelog
---------

2006_07_20 (build 2)
  Fixed a security hole in how the DataBinder was constructed. The old code did this:
          DataBinder serviceBinder = new DataBinder();
          serviceBinder.setEnvironment(SharedObjects.getEnvironment());

  This is a problem, because every DataBinder made from now on will inherit the same
  environment values. This can cause a problem. The correct constuctor is this:
          DataBinder serviceBinder = new DataBinder(
	              SharedObjects.getEnvironment());

  This way, the DataBinder constructor does all the work, and has all the safety belts 
  you need.

2006_06_28 (build 1)
  First Build