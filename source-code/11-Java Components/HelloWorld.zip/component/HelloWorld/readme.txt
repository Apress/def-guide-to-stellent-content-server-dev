HelloWorld Component
====================

This component demonstrates the bare minimum needed for a Java component
to add a new service. Once these services are added, they can be executed
like any other Content Server service: through a web form, through SOAP, or 
from a J2EE app server.
