package helloworld;

import intradoc.common.ServiceException;
import intradoc.data.DataException;
import intradoc.data.DataBinder;
import intradoc.server.ServiceHandler;

public class CustomServiceHandler extends ServiceHandler
{
    public void helloWorld_sayHello3()
        throws DataException, ServiceException
    {
        String name = m_binder.getLocal("name");
        if (name != null && name.length() > 0)
        {
            String helloMessage = "Hello " + name + "!";
            m_binder.putLocal("helloMessage", helloMessage);
        }
    }
}
