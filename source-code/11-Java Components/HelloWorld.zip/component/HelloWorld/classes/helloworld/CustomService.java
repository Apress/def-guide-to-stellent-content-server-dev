package helloworld;

import intradoc.common.ServiceException;
import intradoc.data.DataException;
import intradoc.data.DataBinder;
import intradoc.server.Service;

public class CustomService extends Service
{
    public void helloWorld_sayHello()
        throws DataException, ServiceException
    {
        m_binder.putLocal("StatusMessage", "Hello World!");
    }

	public void helloWorld_sayHello2()
		throws DataException, ServiceException
	{
		String name = m_binder.getLocal("name");
		if (name != null && name.length() > 0)
		{
			String helloMessage = "Hello " + name + "!";
			m_binder.putLocal("helloMessage", helloMessage);
		}
	}
}
