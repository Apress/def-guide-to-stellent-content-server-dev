package CustomAddFiles;

import intradoc.common.FileUtils;
import intradoc.common.ServiceException;
import intradoc.common.StringUtils;
import intradoc.data.DataBinder;
import intradoc.data.DataException;
import intradoc.server.ServiceHandler;

import java.io.File;
import java.io.IOException;
import java.io.Writer;


public class AddFileHandler extends ServiceHandler
{
    public void addFiles() throws ServiceException, DataException
    {
        // pull the alternate file name, if any, from the request
        String altFile = m_binder.getLocal("alternateFile");

        // pull the flag from the request data
        String makeAltFileStr = 
            m_binder.getLocal("createAlternateFile");

        // if no alternate file exists, and the above flag
        // is 'true' in the request, generate the file
        boolean makeAltFile = StringUtils.convertToBool(
            makeAltFileStr, false);
        if ((altFile == null || altFile.length() == 0) && makeAltFile)
            createAlternateTextFile();

        // call the next method called 'addFiles' in the load order.
        m_service.doCodeEx("addFiles", this);
    }

    /**
     * Creates an alternate file for this content item.
     */
    protected void createAlternateTextFile() throws ServiceException
    {
        Writer writer = null;
        try
        {
            // set the format of the alt file to just text
            m_binder.putLocal("alternateFile:format", "text/plain");

            // determine a name for the alternate file
            String docName = m_binder.getLocal("dDocName");
            String name = docName.toLowerCase() + "_alt.txt";
            m_binder.putLocal("alternateFile", name);

            // determine a temp location to build the alternate file
            String fullName = DataBinder.getTemporaryDirectory() +
                DataBinder.getNextFileCounter() + ".txt";
            m_binder.putLocal("alternateFile:path", fullName);

            // add the temp file to the binder
            m_binder.addTempFile(fullName);

            // generate some IdocScript to render as the file string.
            // This can also be pulled from an include, or a template
            String fileString = "Alt file for <$dDocTitle$>:\n" +
                "Author: <$dDocAuthor$>\n" +
                "Comments: <$xComments$>\n" +
                "<$isAbsoluteCgi=1$><$HttpCgiPath$>?IdcService=" +
				"DOC_INFO_BY_NAME&dDocName=<$dDocName$>";

            // render the IdocScript string above with the data
            // currently in the binder
            fileString = 
                m_service.getPageMerger().evaluateScript(fileString);

            // open a file object, and write to it
            writer = FileUtils.openDataWriter(
                new File(fullName), FileUtils.m_javaSystemEncoding);
            writer.write(fileString);
        }
        catch (IOException e)
        {
            throw new ServiceException("Unable to generate" +
                " the alternate file.", e);
        }
        finally
        {
            // close the write object
            FileUtils.closeObject(writer);
        }
    }
}
