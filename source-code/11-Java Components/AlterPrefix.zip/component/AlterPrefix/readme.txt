AlterPrefix Component
=====================

This component demonstrates how to dynamically alter how a service is
processed, and perform metadata validation. It is a simplification of
the DynamicPrefix component in the HowToComponents.