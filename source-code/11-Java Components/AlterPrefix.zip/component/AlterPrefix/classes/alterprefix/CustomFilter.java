package alterprefix;

import intradoc.common.ExecutionContext;
import intradoc.common.ServiceException;
import intradoc.data.DataBinder;
import intradoc.data.DataException;
import intradoc.data.Workspace;
import intradoc.server.Service;
import intradoc.shared.FilterImplementor;
import intradoc.shared.SecurityUtils;
import intradoc.shared.UserData;

public class CustomFilter implements FilterImplementor
{
    public int doFilter(Workspace ws, DataBinder binder,
        ExecutionContext cxt)
        throws DataException, ServiceException
    {
        // obtain the dDocType
        String type = binder.getLocal("dDocType");

        // if it exists (which it always should) set the
        // autonumber prefix to that value
        if (type != null)
        {
            if (type.equals("ADACCT") && cxt instanceof Service)
            {
                UserData user = ((Service)cxt).getUserData();
                if (!SecurityUtils.isUserOfRole(user, "accounting"))
                {
                    throw new ServiceException("User '" +
                        user.m_name + "' is not an accountant.");
                }
            }
            binder.putLocal("AutoNumberPrefix", type + "_");
        }

        // filter executed correctly.  Return CONTINUE
        return FilterImplementor.CONTINUE;
    }
}
