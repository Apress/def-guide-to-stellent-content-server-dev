DatabaseConnections Component
=============================

A sample component to demonstrate how to execute queries in services, 
both with parameters and without parameters. It also shows how to
execute queries against a remote database.
