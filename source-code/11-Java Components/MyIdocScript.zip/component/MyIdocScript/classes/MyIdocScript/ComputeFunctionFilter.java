package MyIdocScript;

import intradoc.common.ExecutionContext;
import intradoc.common.ScriptUtils;
import intradoc.common.ServiceException;
import intradoc.data.DataBinder;
import intradoc.data.DataException;
import intradoc.data.Workspace;
import intradoc.shared.FilterImplementor;
import intradoc.server.Service;

public class ComputeFunctionFilter implements FilterImplementor
{
    /**
     * This filter will be called every time ANY IdocScript function
     * is evaluated. Its an early hook that can allow us to add
     * custom IdocScript functions.
     * @param ws The workspace object for database connectivity
     * @param binder The databinder object for request and response data
     * @param cxt The user/service context of this request
     */
    public int doFilter(Workspace ws, DataBinder binder,
        ExecutionContext cxt) throws DataException, ServiceException
    {
        // pull out the function name and the arguments out
        String function = (String)cxt.getCachedObject("function");
        Object args[] = (Object[])cxt.getCachedObject("args");
        int argLen = args.length;
        Object oResult = null;
        boolean foundIt = false;
        
        if (cxt instanceof Service)
        {
        	boolean isSafe = ((Service)cxt).isConditionVarTrue(
        			"allowWorkflowIdocScript");
        }

        if (function.equals("factorial"))
        {
            if (argLen < 1)
            {
                throw new DataException(
                    "'factorial' requires one argument.");
            }
            long arg1 = ScriptUtils.getLongVal(args[0], cxt);

            long factorial = 1;
            for (long i=1; i <= arg1; i++)
                factorial = factorial * i;
            oResult = new Long(factorial);
            foundIt = true;
        }
        else if (function.equals("strMin"))
        {
            if (argLen < 2)
            {
                throw new DataException(
                   "'strMin' requires two arguments.");
            }
            String arg1 = ScriptUtils.getDisplayString(args[0], cxt);
            String arg2 = ScriptUtils.getDisplayString(args[1], cxt);

            // compare the two strings lexicographically
            int result = arg1.toLowerCase().
                compareTo(arg2.toLowerCase());

            // set the result value to the one that occurs first
            if (result <= 0)
                oResult = arg1;
            else
                oResult = arg2;
            foundIt = true;
        }

        if (foundIt)
        {
            // evaluated the function, so return FINISHED
            // the return value is placed at the end of the result
            args[argLen-1] = oResult;
            return FINISHED;
        }
        else
        {
            // keep looking for the function in the core
            return CONTINUE;
        }
    }
}