SearchFeedback Component
========================

This components adds basic search feedback on the standard content server
interface. It also allows you to expand a search by using the <TYPO>
keywork for Verity full text search.
