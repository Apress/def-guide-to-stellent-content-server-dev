CustomMetadata Component
========================

Sample from the Stellent book.
