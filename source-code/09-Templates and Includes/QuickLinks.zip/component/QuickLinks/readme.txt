QuickLinks Component
====================

This is a sample component that places the PersonalURLS in a sidebar
on the right side of every content server window. It also adds
convenient links to add the current page, and delete links.

This will work in SCS 7.0 and up. It may need CSS modifications on
older systems to make the sidebar look nicer.
